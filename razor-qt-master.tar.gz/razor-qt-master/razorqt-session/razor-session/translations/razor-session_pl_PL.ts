<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>Zgłoszenie błędu sesji Razor</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>Aplikacja &apos;%1&apos; uległa awarii zbyt wiele razy. Automatyczne uruchamianie aplikacji zostało wyłączone w bieżącej sesji.</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>Witamy w Razor-Qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;Witamy w Razor-Qt&lt;/b&gt;
&lt;p&gt;
Przed rozpoczęciem korzystania z komputera, proszę wybrać menedżer okien:</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>Można zmienić menedżer okien w oknie konfiguracji sesji Razor.</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>Inne ...</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>Wybierz swój ulubiony.</translation>
    </message>
</context>
</TS>