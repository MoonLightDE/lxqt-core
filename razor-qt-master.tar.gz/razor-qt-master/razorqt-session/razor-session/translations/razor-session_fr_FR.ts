<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr_FR" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>Rapport de plantage de session Razor</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>L&apos;application &apos;%1&apos; a planté trop souvent. Son redémarrage automatique a été désactivé pour la session courante.</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>Bienvenue sur Razor-qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;Bienvenue sur Razor-qt&lt;/b&gt;
&lt;p&gt;
Avant de commencer à utiliser Razor-qt, vous voulez peut-être choisir un gestionnaire de fenêtres :</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>Vous pouvez changer de gestionnaire de fenêtres à tout moment dans le paneau de configuration de Razor.</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>Autre…</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>Choisissez votre préféré.</translation>
    </message>
</context>
</TS>