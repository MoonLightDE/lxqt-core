<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>Relatar falha da sessão do Razor</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>O aplicativo &apos;%1&apos; falhou muitas vezes. Sua inicialização automática foi desativada para a sessão atual.</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>Bem-vindo ao Razor-qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;Bem-vindo ao Razor-qt&lt;/b&gt;
&lt;p&gt;
Antes de iniciar o uso do Razor-qt, você pode querer selecionar o gerenciador de janelas:</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>Você pode alterar o gerenciador de janelas mais tarde, a qualquer momento através do configurador de sessão do Razor.</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>Outro...</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>Escolha o seu favorito.</translation>
    </message>
</context>
</TS>