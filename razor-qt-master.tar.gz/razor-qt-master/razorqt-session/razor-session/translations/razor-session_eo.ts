<?xml version="1.0" ?><!DOCTYPE TS><TS language="eo" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>Raporto de kolapsoj de Razor-seancoj</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>Aplikaĵo &apos;%1&apos; kolapsis tro ofte. Sia aŭtomata restarto estis malŝaltita por ĉi tiu seanco.</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>Bonvenon en Razor-qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;Bonvenon en Razor-qt&lt;/b&gt;
&lt;p&gt;
Antaŭ startigi uzadon de Razor-qt, vi eble volas elekti la fenestran mastrumilon:</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>Vi povas ŝanĝi la fenestran mastrumilon poste iam ajn per la agordilo de seanco de Razor.</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>Alia...</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>Elektu vian preferatan fenestran mastrumilon.</translation>
    </message>
</context>
</TS>