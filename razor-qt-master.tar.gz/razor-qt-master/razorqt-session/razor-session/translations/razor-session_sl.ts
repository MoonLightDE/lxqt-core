<?xml version="1.0" ?><!DOCTYPE TS><TS language="sl" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>Poročilo o sesutju seje Razor</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>Program »%1« se je sesul prevečkrat. Njegov samodejni zagon za trenutno sejo je bil onemogočen.</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>Dobrodošli v Razor-qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;Dobrodošli v Razor-qt&lt;/b&gt; &lt;p&gt; Preden začnete uporabljati Razor-qt si verjetno želite izbrati upravljalnika oken:</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>Upravljalnika oken lahko kadarkoli spremenite iz nastavitev seje Razor.</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>Drugo ...</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>Izberite priljubljenega upravljalnika oken.</translation>
    </message>
</context>
</TS>