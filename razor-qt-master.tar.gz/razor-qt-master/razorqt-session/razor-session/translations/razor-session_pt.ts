<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>Relatório de erros da sessão Razor</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>A aplicação &apos;%1&apos; terminou muitas vezes. O seu arranque automático foi desativado nesta sessão.</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>Bem-vindo ao Razor-qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;Bem-vindo ao Razor-qt&lt;/b&gt;
&lt;p&gt;
Antes de começar a utilizar o Razor-qt, deve escolher o gestor de janelas:</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>Posteriormente, se quiser, pode alterar o gestor de janelas através do configurador de sessões do Razor.</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>Outro...</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>Escolha o seu preferido.</translation>
    </message>
</context>
</TS>