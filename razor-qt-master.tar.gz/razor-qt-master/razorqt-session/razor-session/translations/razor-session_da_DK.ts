<?xml version="1.0" ?><!DOCTYPE TS><TS language="da_DK" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>Razor-session Nedbrudsrapport</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>Program &apos;%1&apos; har haft nedbrud for mange gange. Programmets autostart er blevet slået fra i denne session.</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>Velkommen til Razor-Qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;Velkommen til Razor-Qt&lt;/b&gt;
&lt;p&gt;
Før du starter Razor-Qt, skal du vælge window manager:</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>Du kan ændre valget af window manager på et vilkårligt tidspunkt.</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>Andre ...
</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>Vælg din favorit.</translation>
    </message>
</context>
</TS>