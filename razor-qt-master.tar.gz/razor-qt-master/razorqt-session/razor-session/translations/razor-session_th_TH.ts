<?xml version="1.0" ?><!DOCTYPE TS><TS language="th_TH" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>รายงานความเสียหายของวาระงาน Razor</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>โปรแกรม &apos;%1&apos; เสียหายหลายครั้งมาก การเริ่มงานอัตโนมัติของมันจะถูกปิดใช้งาานสำหรับวาระงานปัจจุบัน</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>ยินดีต้อนรับเข้าสู่ Razor-qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;ยินดีต้อนรับสู่ Razor-qt&lt;/b&gt;
&lt;p&gt;
ก่อนเริ่มการใช้งาน Razor-qt คุณจะต้องเลือกโปรแกรมจัดการหน้าต่าง:</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>คุณสามารถเปลี่ยนโปรแกรมจัดการหน้าต่างทีหลังในเวลาใดก็ได้ทางตัวตั้งค่าวาระงาน Razor</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>อย่างอื่น ...</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>เลื่อกที่คุณชอบมาหนึ่งอย่าง</translation>
    </message>
</context>
</TS>