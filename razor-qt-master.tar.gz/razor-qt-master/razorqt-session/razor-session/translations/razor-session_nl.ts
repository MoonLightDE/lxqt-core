<?xml version="1.0" ?><!DOCTYPE TS><TS language="nl" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>Razor Sessie Fout Rapport</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>Programma &apos;%1&apos; is te vaak gecrashed. De autorestart functie is uitgeschakeld voor deze sessie.</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>Welkom bij Razor-qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;Welkom bij Razor-qt&lt;/b&gt;⏎
&lt;p&gt;⏎
Voordat u gebruik maakt van Razor-Qt, wilt u wellicht een Window Manager selecteren:</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>U kunt ook op een later tijdstip van Window Manager wisselen, via de Razor Sessie Configurator.</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>Overige ...</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>Kies uw favoriete.</translation>
    </message>
</context>
</TS>