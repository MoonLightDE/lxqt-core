<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt" version="2.0">
<context>
    <name>RazorModuleManager</name>
    <message>
        <source>Razor Session Crash Report</source>
        <translation>Pranešimas apie Razor sesijų lūžimus</translation>
    </message>
    <message>
        <source>Application &apos;%1&apos; crashed too many times. Its autorestart has been disabled for current session.</source>
        <translation>Programa „%1“ dažnai nulūžta. Jos automatinis paleidimas išjungiamas šiai sesijai.</translation>
    </message>
</context>
<context>
    <name>WmSelectDialog</name>
    <message>
        <source>Welcome to Razor-qt</source>
        <translation>Jus sveikina Razor-qt</translation>
    </message>
    <message>
        <source>&lt;b&gt;Welcome to Razor-qt&lt;/b&gt;
&lt;p&gt;
Before starting to use the Razor-qt, you might want to select the Windows Manager:</source>
        <translation>&lt;b&gt;Jus sveikina Razor-qt&lt;/b&gt;
&lt;p&gt;
Prieš pradėdami dirbti Razor-qt aplinkoje, pasirinkite norimą langų tvarkyklę.</translation>
    </message>
    <message>
        <source>You can change the Window Manager later at any time via Razor Session Configurator.</source>
        <translation>Langų tvarkyklę bet kada vėliau galėsite pasikeisti Razor sesijų konfigūracijoje.</translation>
    </message>
    <message>
        <source>Other ...</source>
        <translation>Kita ...</translation>
    </message>
    <message>
        <source>Choose your favorite one.</source>
        <translation>Pasirinkite norimą.</translation>
    </message>
</context>
</TS>