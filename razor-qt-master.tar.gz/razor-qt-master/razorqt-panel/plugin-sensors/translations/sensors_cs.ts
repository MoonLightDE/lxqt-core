<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs" version="2.0">
<context>
    <name>RazorSensorsConfiguration</name>
    <message>
        <source>Razor Sensors Settings</source>
        <translation>Nastavení čidel</translation>
    </message>
    <message>
        <source>Common</source>
        <translation>Běžné</translation>
    </message>
    <message>
        <source>Update interval (seconds)</source>
        <translation>Obnovovací interval (v sekundách)</translation>
    </message>
    <message>
        <source>Temperature bar width</source>
        <translation>Šířka proužku s teplotou</translation>
    </message>
    <message>
        <source>Temperature scale</source>
        <translation>Teplotní stupnice</translation>
    </message>
    <message>
        <source>Celsius</source>
        <translation>Celsius</translation>
    </message>
    <message>
        <source>Fahrenheit</source>
        <translation>Fahrenheit</translation>
    </message>
    <message>
        <source>Blink progress bars when the temperature is too high</source>
        <translation>Blikat proužky ukazujícími nárůst teploty, když je teplota příliš vysoká</translation>
    </message>
    <message>
        <source>Warning about high temperature</source>
        <translation>Varování při vysoké teplotě</translation>
    </message>
    <message>
        <source>Sensors</source>
        <translation>Čidla</translation>
    </message>
    <message>
        <source>Detected chips:</source>
        <translation>Zjištěné čipy:</translation>
    </message>
    <message>
        <source>Chip features:</source>
        <translation>Vlastnosti čipů:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Povoleno</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Štítek</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
</context>
</TS>