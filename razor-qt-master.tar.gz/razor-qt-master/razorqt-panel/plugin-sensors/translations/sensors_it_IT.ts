<?xml version="1.0" ?><!DOCTYPE TS><TS language="it_IT" version="2.0">
<context>
    <name>RazorSensorsConfiguration</name>
    <message>
        <source>Razor Sensors Settings</source>
        <translation>Impostazioni dei sensori di Razor</translation>
    </message>
    <message>
        <source>Common</source>
        <translation>Comune</translation>
    </message>
    <message>
        <source>Update interval (seconds)</source>
        <translation>Intervallo di aggiornamento (secondi)</translation>
    </message>
    <message>
        <source>Temperature bar width</source>
        <translation>Larghezza della barra della temperatura</translation>
    </message>
    <message>
        <source>Temperature scale</source>
        <translation>Scala della temperatura</translation>
    </message>
    <message>
        <source>Celsius</source>
        <translation>Celsius</translation>
    </message>
    <message>
        <source>Fahrenheit</source>
        <translation>Fahrenheit</translation>
    </message>
    <message>
        <source>Blink progress bars when the temperature is too high</source>
        <translation>Barre di avanzamento lampeggianti quando la temperatura è troppo elevata</translation>
    </message>
    <message>
        <source>Warning about high temperature</source>
        <translation>Avvertimento per la temperatura elevata</translation>
    </message>
    <message>
        <source>Sensors</source>
        <translation>Sensori</translation>
    </message>
    <message>
        <source>Detected chips:</source>
        <translation>Chip rilevati:</translation>
    </message>
    <message>
        <source>Chip features:</source>
        <translation>Caratteristiche del chip:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Attivato</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Colore</translation>
    </message>
</context>
</TS>