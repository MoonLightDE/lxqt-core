<?xml version="1.0" ?><!DOCTYPE TS><TS language="fi" version="2.0">
<context>
    <name>RazorSensorsConfiguration</name>
    <message>
        <source>Razor Sensors Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Common</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Update interval (seconds)</source>
        <translation>Päivitysväli (sekunneissa)</translation>
    </message>
    <message>
        <source>Temperature bar width</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Temperature scale</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Celsius</source>
        <translation>Celsius</translation>
    </message>
    <message>
        <source>Fahrenheit</source>
        <translation>Fahrenheit</translation>
    </message>
    <message>
        <source>Blink progress bars when the temperature is too high</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Warning about high temperature</source>
        <translation>Varoitus korkeasta lämpötilasta</translation>
    </message>
    <message>
        <source>Sensors</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Detected chips:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Chip features:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Käytössä</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Nimike</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Väri</translation>
    </message>
</context>
</TS>