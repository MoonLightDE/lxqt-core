<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.0">
<context>
    <name>RazorSensorsConfiguration</name>
    <message>
        <source>Razor Sensors Settings</source>
        <translation>Razor溫度感應設定</translation>
    </message>
    <message>
        <source>Common</source>
        <translation>一般</translation>
    </message>
    <message>
        <source>Update interval (seconds)</source>
        <translation>更新間隔(秒)</translation>
    </message>
    <message>
        <source>Temperature bar width</source>
        <translation>溫度計寬度</translation>
    </message>
    <message>
        <source>Temperature scale</source>
        <translation>溫標</translation>
    </message>
    <message>
        <source>Celsius</source>
        <translation>攝氏</translation>
    </message>
    <message>
        <source>Fahrenheit</source>
        <translation>華式</translation>
    </message>
    <message>
        <source>Blink progress bars when the temperature is too high</source>
        <translation>當溫度太高時溫度計閃爍</translation>
    </message>
    <message>
        <source>Warning about high temperature</source>
        <translation>高溫警告</translation>
    </message>
    <message>
        <source>Sensors</source>
        <translation>感應器</translation>
    </message>
    <message>
        <source>Detected chips:</source>
        <translation>偵測晶片:</translation>
    </message>
    <message>
        <source>Chip features:</source>
        <translation>晶片資訊</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>允許</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>標籤</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>顏色</translation>
    </message>
</context>
</TS>