<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru_RU" version="2.0">
<context>
    <name>RazorSensorsConfiguration</name>
    <message>
        <source>Razor Sensors Settings</source>
        <translation>Настройки сенсоров</translation>
    </message>
    <message>
        <source>Common</source>
        <translation>Общие</translation>
    </message>
    <message>
        <source>Update interval (seconds)</source>
        <translation>Интервал обновления(сек)</translation>
    </message>
    <message>
        <source>Temperature bar width</source>
        <translation>Ширина столбца</translation>
    </message>
    <message>
        <source>Temperature scale</source>
        <translation>Температурная шкала в градусах</translation>
    </message>
    <message>
        <source>Celsius</source>
        <translation>Цельсия</translation>
    </message>
    <message>
        <source>Fahrenheit</source>
        <translation>Фаренгейта</translation>
    </message>
    <message>
        <source>Blink progress bars when the temperature is too high</source>
        <translation>Подсвечивать индикатор при высокой температуре</translation>
    </message>
    <message>
        <source>Warning about high temperature</source>
        <translation>Предупреждение о высокой температуре</translation>
    </message>
    <message>
        <source>Sensors</source>
        <translation>Сенсоры</translation>
    </message>
    <message>
        <source>Detected chips:</source>
        <translation>Обнаруженные чипы:</translation>
    </message>
    <message>
        <source>Chip features:</source>
        <translation>Возможности чипа:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Включено</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Цвет</translation>
    </message>
</context>
</TS>