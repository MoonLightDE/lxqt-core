<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_VE" version="2.0">
<context>
    <name>RazorSensorsConfiguration</name>
    <message>
        <source>Razor Sensors Settings</source>
        <translation>preferencias de sensor Razor</translation>
    </message>
    <message>
        <source>Common</source>
        <translation>Comunes</translation>
    </message>
    <message>
        <source>Update interval (seconds)</source>
        <translation>Intervalo de actualizacion (segundos)</translation>
    </message>
    <message>
        <source>Temperature bar width</source>
        <translation>Ancho de la barra indicadora</translation>
    </message>
    <message>
        <source>Temperature scale</source>
        <translation>Escala de temperatura</translation>
    </message>
    <message>
        <source>Celsius</source>
        <translation>Celcios</translation>
    </message>
    <message>
        <source>Fahrenheit</source>
        <translation>Fahrenheit</translation>
    </message>
    <message>
        <source>Blink progress bars when the temperature is too high</source>
        <translation>parpadear la barra de indicacion cuando la temperatura es alta </translation>
    </message>
    <message>
        <source>Warning about high temperature</source>
        <translation>Advertir acerca de altas temperaturas</translation>
    </message>
    <message>
        <source>Sensors</source>
        <translation>Sensores</translation>
    </message>
    <message>
        <source>Detected chips:</source>
        <translation>Chips detectados</translation>
    </message>
    <message>
        <source>Chip features:</source>
        <translation>Chips caracteristicas:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Color</translation>
    </message>
</context>
</TS>