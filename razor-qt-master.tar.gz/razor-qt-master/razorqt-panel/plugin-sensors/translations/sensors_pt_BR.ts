<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.0">
<context>
    <name>RazorSensorsConfiguration</name>
    <message>
        <source>Razor Sensors Settings</source>
        <translation>Configuraçoes Dos Sensores</translation>
    </message>
    <message>
        <source>Common</source>
        <translation>Comum</translation>
    </message>
    <message>
        <source>Update interval (seconds)</source>
        <translation>Intervalo de atualização (segundos)</translation>
    </message>
    <message>
        <source>Temperature bar width</source>
        <translation>Temperatura em barra com</translation>
    </message>
    <message>
        <source>Temperature scale</source>
        <translation>Temperatura em escala</translation>
    </message>
    <message>
        <source>Celsius</source>
        <translation>Celsius</translation>
    </message>
    <message>
        <source>Fahrenheit</source>
        <translation>Fahrenheit</translation>
    </message>
    <message>
        <source>Blink progress bars when the temperature is too high</source>
        <translation>Piscar a barra de progresso quando a temperatura está muito alta</translation>
    </message>
    <message>
        <source>Warning about high temperature</source>
        <translation>Alertar sobre a alta temperatura</translation>
    </message>
    <message>
        <source>Sensors</source>
        <translation>Sensores</translation>
    </message>
    <message>
        <source>Detected chips:</source>
        <translation>Chips detectados:</translation>
    </message>
    <message>
        <source>Chip features:</source>
        <translation>Características do chips:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
</context>
</TS>