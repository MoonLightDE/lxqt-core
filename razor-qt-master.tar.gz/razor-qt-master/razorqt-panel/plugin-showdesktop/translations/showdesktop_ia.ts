<?xml version="1.0" ?><!DOCTYPE TS><TS language="ia" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <location filename="../showdesktop.cpp" line="55"/>
        <source>Global keyboard shortcut</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../showdesktop.cpp" line="56"/>
        <source>Panel Show Desktop Global shortcut: &apos;%1&apos; cannot be registered</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../showdesktop.cpp" line="61"/>
        <source>Show Desktop</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>