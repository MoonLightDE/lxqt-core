<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr_FR" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Montrer le bureau : le raccourci global &apos;%1&apos; ne peut pas être défini</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Montrer le bureau</translation>
    </message>
</context>
</TS>