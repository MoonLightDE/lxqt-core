<?xml version="1.0" ?><!DOCTYPE TS><TS language="nl" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Bureaublad weergeven: Global snelkoppeling &apos;%1&apos; kan niet worden geregistreerd</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Toon Bureaublad</translation>
    </message>
</context>
</TS>