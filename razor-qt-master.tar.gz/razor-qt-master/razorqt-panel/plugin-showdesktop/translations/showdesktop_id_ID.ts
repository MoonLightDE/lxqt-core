<?xml version="1.0" ?><!DOCTYPE TS><TS language="id_ID" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Tampilkan Desktop</translation>
    </message>
</context>
</TS>