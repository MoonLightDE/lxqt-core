<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs_CZ" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Ukázat plochu: Celkovou zkratku &apos;%1&apos; nelze zapsat</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Ukázat pracovní plochu</translation>
    </message>
</context>
</TS>