<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Rodyti darbalaukį: globalusis klavišas „%1“ negali būti registruojamas</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Rodyti darbalaukį</translation>
    </message>
</context>
</TS>