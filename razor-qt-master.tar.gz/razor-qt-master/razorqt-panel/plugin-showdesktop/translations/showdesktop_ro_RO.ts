<?xml version="1.0" ?><!DOCTYPE TS><TS language="ro_RO" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Afișează desktopul</translation>
    </message>
</context>
</TS>