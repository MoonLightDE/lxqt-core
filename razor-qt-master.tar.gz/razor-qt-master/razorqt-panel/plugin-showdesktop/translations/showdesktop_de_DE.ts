<?xml version="1.0" ?><!DOCTYPE TS><TS language="de_DE" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Zeige Desktop: Globales Tastenkürzel &apos;%1&apos; kann nicht vergeben werden</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Zeige Desktop</translation>
    </message>
</context>
</TS>