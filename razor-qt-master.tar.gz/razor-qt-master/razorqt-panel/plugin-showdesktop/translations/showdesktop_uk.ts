<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Показати стільницю: Не вдалося зареєструвати глобальне скорочення &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Показати стільницю</translation>
    </message>
</context>
</TS>