<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="sr_BA">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Global keyboard shortcut</source>
        <translation>Глобална пречица тастатуре</translation>
    </message>
    <message>
        <source>Panel Show Desktop Global shortcut: &apos;%1&apos; cannot be registered</source>
        <translation>Глобална пречица приказа површи за панел: „%1“ не може бити регистрована</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Прикажи радну површ</translation>
    </message>
</context>
</TS>
