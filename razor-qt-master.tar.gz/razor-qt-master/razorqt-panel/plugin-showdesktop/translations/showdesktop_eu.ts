<?xml version="1.0" ?><!DOCTYPE TS><TS language="eu" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Erakutsi mahaigaina: Ezin da &apos;%1&apos; lasterbide globala erregistratu</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Erakutsi mahaigaina</translation>
    </message>
</context>
</TS>