<?xml version="1.0" ?><!DOCTYPE TS><TS language="da_DK" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Vis Skrivebord: Global genvej &apos;%1&apos; kan ikke registreres</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Vis Skrivebord</translation>
    </message>
</context>
</TS>