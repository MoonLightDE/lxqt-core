<?xml version="1.0" ?><!DOCTYPE TS><TS language="it_IT" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Mostra desktop: la scorciatoia globale &apos;%1&apos; non può essere registrata</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Mostra desktop</translation>
    </message>
</context>
</TS>