<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>顯示桌面:全域快捷鍵&apos;%1&apos;無法被註冊</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>顯示桌面</translation>
    </message>
</context>
</TS>