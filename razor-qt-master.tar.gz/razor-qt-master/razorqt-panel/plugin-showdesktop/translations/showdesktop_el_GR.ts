<?xml version="1.0" ?><!DOCTYPE TS><TS language="el_GR" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Εμφάνιση επιφάνειας εργασίας: Δεν είναι δυνατή η καταχώριση της καθολικής συντόμευσης &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Εμφάνιση επιφάνειας εργασίας</translation>
    </message>
</context>
</TS>