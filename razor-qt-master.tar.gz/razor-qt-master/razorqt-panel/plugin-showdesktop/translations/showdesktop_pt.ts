<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Tecla de atalho global: &apos;%1&apos; não pode ser registada</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Mostrar área de trabalho</translation>
    </message>
</context>
</TS>