<?xml version="1.0" ?><!DOCTYPE TS><TS language="es" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Mostrar Escritorio: Atajo global &apos;%1&apos; no puede ser registrado</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Mostrar Escritorio</translation>
    </message>
</context>
</TS>