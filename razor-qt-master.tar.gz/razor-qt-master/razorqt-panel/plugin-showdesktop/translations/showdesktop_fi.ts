<?xml version="1.0" ?><!DOCTYPE TS><TS language="fi" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Näytä työpöytä: globaalia pikanäppäintä &apos;%1&apos; ei voi rekisteröidä</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Näytä työpöytä</translation>
    </message>
</context>
</TS>