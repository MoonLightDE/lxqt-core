<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Pokaż Pulpit: Globalny skrót &apos;%1&apos; nie może zostać zarejestrowany</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Pokaż pulpit</translation>
    </message>
</context>
</TS>