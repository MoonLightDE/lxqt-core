<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>显示桌面：无法注册全局快捷键&apos;%1&apos;</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>显示桌面</translation>
    </message>
</context>
</TS>