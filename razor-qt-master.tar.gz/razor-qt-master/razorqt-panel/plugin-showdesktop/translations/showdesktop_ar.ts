<?xml version="1.0" ?><!DOCTYPE TS><TS language="ar" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>إظهار سطح المكتب: ﻻ يمكن تسجيل اختصار لوحة المفاتيح العامُّ `%1`</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>إظهار سطح المكتب</translation>
    </message>
</context>
</TS>