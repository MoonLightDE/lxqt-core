<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_VE" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Mostrar escritorio: Acceso de teclado global &apos;%1&apos; no puede registrarse</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Mostrar Escritorio</translation>
    </message>
</context>
</TS>