<?xml version="1.0" ?><!DOCTYPE TS><TS language="eo" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Montri labortablon: ĉiea klavkombino &apos;%1&apos; ne registreblas</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Montri labortablon</translation>
    </message>
</context>
</TS>