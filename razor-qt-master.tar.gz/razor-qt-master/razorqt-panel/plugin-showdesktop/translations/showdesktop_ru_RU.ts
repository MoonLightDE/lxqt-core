<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru_RU" version="2.0">
<context>
    <name>ShowDesktop</name>
    <message>
        <source>Show Desktop: Global shortcut &apos;%1&apos; cannot be registered</source>
        <translation>Показатйл Рабочий стол: &apos;%1&apos; Глобальное кратчайший путь  не могут быть зарегистрированы</translation>
    </message>
    <message>
        <source>Show Desktop</source>
        <translation>Показать рабочий стол</translation>
    </message>
</context>
</TS>