/* 
 * File:   RazorqtRunner.h
 * Author: alexis
 *
 * Created on 2 de septiembre de 2013, 11:15
 */

#ifndef RAZORQTRUNNER_H
#define	RAZORQTRUNNER_H

#include <QObject>
#include <Core.h>
#include <LxqtModuleInterface.h>

#include "../dialog.h"

class LxqtMod_Runner: public LxqtModuleInterface {
    Q_OBJECT
    Q_INTERFACES(LxqtModuleInterface)
public:
    virtual void init(Core* core);
    virtual QString getId();
    
    LxqtMod_Runner();
    LxqtMod_Runner(const LxqtMod_Runner& orig);
    virtual ~LxqtMod_Runner();
private:
    Core* m_core;
    Dialog* m_dialog;

};

#endif	/* RAZORQTRUNNER_H */

