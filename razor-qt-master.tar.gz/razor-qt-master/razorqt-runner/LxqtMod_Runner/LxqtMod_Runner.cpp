/* 
 * File:   RazorqtRunner.cpp
 * Author: alexis
 * 
 * Created on 2 de septiembre de 2013, 11:15
 */

#include "LxqtMod_Runner.h"


LxqtMod_Runner::LxqtMod_Runner() {
}

LxqtMod_Runner::LxqtMod_Runner(const LxqtMod_Runner& orig) {
}

LxqtMod_Runner::~LxqtMod_Runner() {
    delete m_dialog;
}

QString LxqtMod_Runner::getId() {
    return "LxqtMod_Runner";
}

void LxqtMod_Runner::init(Core* core) {
    m_core = core;
    core->getRazorApp()->setQuitOnLastWindowClosed(false);
    
    QWidget *hiddenPreviewParent = new QWidget(0, Qt::Tool);
    m_dialog = new Dialog(hiddenPreviewParent);
    //m_dialog->show();
}

QT_BEGIN_NAMESPACE
Q_EXPORT_PLUGIN2(LxqtMod_Runner, LxqtMod_Runner)
QT_END_NAMESPACE
