<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Definições</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Posição:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Mostrar:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Atalho:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Limite superior do ecrã</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Centro do ecrã</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Monitor do rato</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Sempre no monitor %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Lançador de aplicações</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Configurar razor-runner</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Apagar histórico</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Prima &quot;%1&quot; para abrir a caixa de diálogo</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Histórico</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matemática</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Gestão de energia Razor</translation>
    </message>
</context>
</TS>