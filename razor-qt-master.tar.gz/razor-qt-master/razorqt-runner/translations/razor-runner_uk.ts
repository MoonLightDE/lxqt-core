<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Налаштування запускача програм Razor</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Вигляд</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Розташування:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Монітор:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Клавіатурне скорочення:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Зверху екрану</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Посередині екрану</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Де курсор миші</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Завжди №%1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Запускач програм </translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Налаштувати запускач програм Razor</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Стерти історію razor-runner</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Натисніть &quot;%1&quot; для відкриття діалогу.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Історія</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Математика</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Керування живленням Razor</translation>
    </message>
</context>
</TS>