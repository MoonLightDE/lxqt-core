<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Razor paleidiklio nuostatos</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Išvaizda</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Padėtis:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Rodyti:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Nuoroda:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Viršutiniame ekrano krašte</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Ekrano centre</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Ties pele</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Visada „%1“ vaizduoklyje</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Programų paleidiklis</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Konfigūruoti razor paleidiklį</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Išvalyti razor paleidiklio istoriją</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Norėdami matyti dialogą, spauskite „%1“</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Istorija</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematika</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razor energijos valdymas</translation>
    </message>
</context>
</TS>