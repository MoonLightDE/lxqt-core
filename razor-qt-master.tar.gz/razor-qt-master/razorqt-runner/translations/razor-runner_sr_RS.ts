<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr_RS" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Подешавања Рејзор-покретача</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Изглед</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Позиција:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Прикажи на:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Пречица:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>горња ивица екрана</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>центар екрана</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>екрану на ком је миш</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>увек на екрану %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Покретач програма</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Подеси Рејзор-покретача</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Притисните „%1“ да бисте видели дијалог.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Историјат</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Математика</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>