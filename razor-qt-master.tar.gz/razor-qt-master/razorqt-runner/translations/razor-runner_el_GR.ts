<?xml version="1.0" ?><!DOCTYPE TS><TS language="el_GR" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Ρυθμίσεις εκτελεστή Razor</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Εμφάνιση</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Θέση:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Εμφάνιση σε:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Συντόμευση:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Επάνω άκρη της οθόνης</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Κέντρο της οθόνης</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Οθόνη όπου βρίσκεται το ποντίκι</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Πάντα στην οθόνη %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Εκκινητής εφαρμογής </translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Διαμόρφωση εκτελεστή razor</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Εκκαθάριση ιστορικού εκτελεστή razor</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Πιέστε &quot;%1&quot; για εμφάνιση διαλόγου.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Ιστορία</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Μαθηματικά</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Διαχείριση ενέργειας Razor</translation>
    </message>
</context>
</TS>