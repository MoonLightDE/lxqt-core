<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Ustawienia Razor-runner</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Wygląd</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Pozycja:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Pokasz na:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Skrót:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Góra ekarnu</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Środek ekranu</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Tam gdzie mysz</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Zawsze na %1 ekranie</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Komenda</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Konfiguruj razor-runner</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Wyczyść Historię razor-runnera</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Naciśnij &quot;%1&quot; aby zobaczyć okno.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematyka</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Menadżer Zasilania Razor</translation>
    </message>
</context>
</TS>