<?xml version="1.0" ?><!DOCTYPE TS><TS language="eo" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Agordoj de razor-runner</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Apero</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Loko:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Montri en:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Klavkombino:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Supra bordo de la ekrano</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Centro de la ekrano</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Ĉiam en %1 monitoro</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Lanĉilo de aplikaĵoj </translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Agordi razor-runner</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Vakigi kronologion de razor-runner</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Alkalku &quot;%1&quot; por montri dialogon.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Historio</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematiko</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Kurentmastrumilo de Razor</translation>
    </message>
</context>
</TS>