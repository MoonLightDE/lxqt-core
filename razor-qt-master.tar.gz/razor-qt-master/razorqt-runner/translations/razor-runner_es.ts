<?xml version="1.0" ?><!DOCTYPE TS><TS language="es" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Configuración de Razor-runner</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Posición:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Mostrar en:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Acceso directo</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Extremo superior de la pantalla</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Centro de la pantalla</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Monitor donde esté el ratón</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Siempre en el monitor %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Lanzador de aplicaciones</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Configurar razor-runner</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Limpiar historial de Razor-Runner</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Presione &quot;%1&quot; para ver la pantalla.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Historial</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matemáticas</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Administrador de energía de Razor</translation>
    </message>
</context>
</TS>