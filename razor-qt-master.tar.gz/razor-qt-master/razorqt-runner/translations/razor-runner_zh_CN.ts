<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Razor启动器设置</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>外观</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>位置:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>显示在:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>快捷键:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>屏幕顶部</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>屏幕中部</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>鼠标所在的显示器</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>总是在 %1 显示器</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>应用程序启动器</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>配置Razor启动器</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>清空 razor-runner 历史</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>按下 &quot;%1&quot; 以查看对话框。</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>历史</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>数学</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razor 电源管理</translation>
    </message>
</context>
</TS>