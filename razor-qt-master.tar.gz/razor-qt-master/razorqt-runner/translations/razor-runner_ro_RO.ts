<?xml version="1.0" ?><!DOCTYPE TS><TS language="ro_RO" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Setări razor-runner</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Aspect</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Poziție:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Afișează pe:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Scurtătură:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Marginea superioară a ecranului</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Centrul ecranului</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Monitorizează unde este mausul</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Întotdeauna pe monitorul %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Lansator de aplicații</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Configurare razor-runner</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Curăță istoricul razor-runner</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Apăsați &quot;%1&quot; pentru a afișa dialogul.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Istoric</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematică</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Gestiune alimentare Razor</translation>
    </message>
</context>
</TS>