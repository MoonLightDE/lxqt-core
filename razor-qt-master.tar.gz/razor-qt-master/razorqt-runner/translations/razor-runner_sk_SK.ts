<?xml version="1.0" ?><!DOCTYPE TS><TS language="sk_SK" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Nastavenia Spúšťača Razor</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Vzhľad</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Pozícia:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Kde zobrazovať:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Skratka:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Horný okraj obrazovky</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Stred obrazovky</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Monitor, kde je myš</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Vždy na monitore %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Spúšťač aplikácií</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Nastaviť Spúšťač Razor</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Stlačením „%1“ zobrazte dialóg.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>História</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematika</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>