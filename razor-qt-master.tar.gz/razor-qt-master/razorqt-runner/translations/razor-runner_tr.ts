<?xml version="1.0" ?><!DOCTYPE TS><TS language="tr" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Razor-çalıştırıcı Ayarları</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Görünüm</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Konumlandırma:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Şunda Göster:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Kısayol:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Ekranın üst köşesi</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Ekranın merkezi</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Fare konumunda görüntüle</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Her zaman %1 ekranında</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Uygulama başlatıcı </translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Razor-çalıştırıcıyı yapılandır</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Razor-çalıştırıcı geçmişini temizle</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Diyaloğu görmek için &quot;%1&quot; üzerine basın</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Geçmiş</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>İşlemler</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razor Güç Yönetimi</translation>
    </message>
</context>
</TS>