<?xml version="1.0" ?><!DOCTYPE TS><TS language="da_DK" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Programstarter Indstillinger</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Udseende</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Position:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Vis på:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Genvej:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Skærmens topkant</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Skærmens midte</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Skærmen, hvor musen</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Altid på skærm %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Programstarter</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Indstil Razor programstarter</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Nulstil razor programstarter historik</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Tryk &quot;%1&quot; for at se dialog.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Historie</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematik</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razor Strømstyring</translation>
    </message>
</context>
</TS>