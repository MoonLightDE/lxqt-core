<?xml version="1.0" ?><!DOCTYPE TS><TS language="ja" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Razor-runnerの設定</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>外観</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>配置:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>表示:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>ショートカット:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>スクリーンの上辺</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>スクリーンの中央</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>マウスの位置を観察</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>常に%1モニタに</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>アプリケーションランチャ</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>razor-runnerを設定</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Razor-runnerの履歴を消去</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>ダイアログを見るには&quot;%1&quot;を押してください。</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>履歴</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>計算</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razor電源管理</translation>
    </message>
</context>
</TS>