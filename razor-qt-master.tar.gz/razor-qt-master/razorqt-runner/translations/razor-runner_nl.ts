<?xml version="1.0" ?><!DOCTYPE TS><TS language="nl" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Razor-uitvoeren Instellingen</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Uiterlijk</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Positionering:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Toon op:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Snelkoppeling:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Bovenkant van het scherm</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Midden van het scherm</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Check positie van de muis</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Altijd op %1 monitor</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Programma starter</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Configureer Razor-uitvoeren</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Wis razor-runner Geschiedenis</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Toets &quot;%1&quot; om dialoog te zien.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Geschiedenis</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Wiskundig</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razor Energiebeheer</translation>
    </message>
</context>
</TS>