<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru_RU" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Настройки Razor-runner</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Внешний вид</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Позиция:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Показывать на:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Горячая клавиша:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Наверху экрана</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>В центре экрана</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Монитор на котором мышь</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Всегда на %1 мониторе</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Запускалка програм</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Настроить razor-runner</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Очистить историю razor-runner</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Нажмите &quot;%1&quot; чтобы увидеть диалог.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Из истории</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Математика</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Управление питанием Razor</translation>
    </message>
</context>
</TS>