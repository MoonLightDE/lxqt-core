<?xml version="1.0" ?><!DOCTYPE TS><TS language="ar" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>إعدادات مُطلق ريزر</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>المظهر</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>تحديد الموضع:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>إظهارٌ على:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>رابطٌ مختصر:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>الحافَّة العليا للشَّاشة</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>مركز الشَّاشة</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>المراقبة عند مؤشر الفأرة</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>دوماً في شاشة العرض %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>بادئ التطبيقات</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>تهيئة مُطلق نظام ريزر</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>مسح ذاكرة مُنفِّذ برامج ريزر</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>اضغط &quot;%1&quot; لمشاهدة لوحة الحوار.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>سجلُّ السوابق</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>الرِّياضيَّات</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>إدارة الطاقة لبيئة ريزر</translation>
    </message>
</context>
</TS>