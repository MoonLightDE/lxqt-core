<?xml version="1.0" ?><!DOCTYPE TS><TS language="fi" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Razorin käynnistimen asetukset</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Ulkoasu</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Näytä:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Pikanäppäin:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Näytön ylälaidassa</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Keskellä näyttöä</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Näytöllä, jossa hiiren osoitin on</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Aina näytöllä %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Sovelluskäynnistin </translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Hallitse Razorin käynnistintä</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Tyhjennä Razor-käynnistimen historia</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Paina &quot;%1&quot; nähdäksesi ikkunan.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematiikka</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razorin virranhallinta</translation>
    </message>
</context>
</TS>