<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr_FR" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Paramètres du lanceur de commandes</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Apparence</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Position :</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Montrer au :</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Raccourci :</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Bord supérieur de l&apos;écran</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Centre de l&apos;écran</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Moniteur où se trouve la souris</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Toujours sur le moniteur %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Lanceur d&apos;application</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Configurer le lanceur de commandes</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Effacer l&apos;historique du lanceur de commandes</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Appuyer sur &quot;%1&quot; pour voir le dialogue</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Histoire</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Mathématiques</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Gestion de l&apos;énergie</translation>
    </message>
</context>
</TS>