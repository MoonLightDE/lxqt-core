<?xml version="1.0" ?><!DOCTYPE TS><TS language="sl" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Nastavitve za Razor-runner</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Videz</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Položaj:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Pokaži na:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Bližnjica:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Vrhnjem robu zaslona</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Sredini zaslona</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Zaslonu, kjer je miška</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Vedno na zaslonu %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Zaganjalnik programov </translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Nastavitve za Razor-runner</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Počisti zgodovino za Razor-runner</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Za prikaz pogovornega okna pritisnite »%1«.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Zgodovina</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematika</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Upravljanje z energijo</translation>
    </message>
</context>
</TS>