<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Razor快速執行設定</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>外觀</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>位於:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>顯示在:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>快捷鍵:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>螢幕頂端</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>螢幕中間</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>在滑鼠所在的顯示器</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>總是在%1顯示器</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>應用程式啟動器</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>設定Razor快速執行</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>清除Razor快速執行的歷史紀錄</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>按下&quot;%1&quot;檢視對話。</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>歷史記錄</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>數學</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razor電源管理</translation>
    </message>
</context>
</TS>