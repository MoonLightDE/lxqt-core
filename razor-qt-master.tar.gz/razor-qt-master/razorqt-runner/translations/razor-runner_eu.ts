<?xml version="1.0" ?><!DOCTYPE TS><TS language="eu" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Razor-runner ezarpenak</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Itxura</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Posizioa:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Erakutsi hemen:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Lasterbidea:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Pantailaren goiko ertza</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Pantailaren erdia</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Monitorea sagua dagoen lekuan</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Beti %1 monitorean</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Aplikazio-abiarazlea</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Konfiguratu razor-runner</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Garbitu razor-runner historia</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Sakatu &quot;%1&quot; elkarrizketa-koadroa ikusteko.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematikak</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razor energia-kudeaketa</translation>
    </message>
</context>
</TS>