<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Nastavení spouštěče programů</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Vzhled</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Umístění:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Ukázat na:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Klávesová zkratka:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Horní okraj obrazovky</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Střed obrazovky</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Tam, kde je myš</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Vždy na %1 obrazovce</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Spouštěč programů</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Nastavit spouštěč programů</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Smazat historii spouštěče programů</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Stiskněte &quot;%1&quot; pro zobrazení dialogu.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Historie</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Matematika</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Správa energie</translation>
    </message>
</context>
</TS>