<?xml version="1.0" ?><!DOCTYPE TS><TS language="de_DE" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Razor-runner Settings</source>
        <translation>Razor-runner-Einstellungen</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Aussehen</translation>
    </message>
    <message>
        <source>Positioning:</source>
        <translation>Positionierung:</translation>
    </message>
    <message>
        <source>Show on:</source>
        <translation>Anzeigen auf:</translation>
    </message>
    <message>
        <source>Shortcut:</source>
        <translation>Tastenkürzel:</translation>
    </message>
    <message>
        <source>Top edge of screen</source>
        <translation>Bildschirmoberkante</translation>
    </message>
    <message>
        <source>Center of screen</source>
        <translation>Bildschirmmitte</translation>
    </message>
    <message>
        <source>Monitor where the mouse</source>
        <translation>Anzeigen, wo die Maus ist</translation>
    </message>
    <message>
        <source>Always on %1 monitor</source>
        <translation>Immer auf Monitor %1</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <source>Application launcher </source>
        <translation>Anwendungsstarter</translation>
    </message>
    <message>
        <source>Configure razor-runner</source>
        <translation>Konfiguriere razor-runner</translation>
    </message>
    <message>
        <source>Clear razor-runner History</source>
        <translation>Razor-runner Verlauf löschen</translation>
    </message>
    <message>
        <source>Press &quot;%1&quot; to see dialog.</source>
        <translation>Klicke &quot;%1&quot; für Dialogsansicht.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>History</source>
        <translation>Verlauf</translation>
    </message>
    <message>
        <source>Mathematics</source>
        <translation>Mathematik</translation>
    </message>
    <message>
        <source>Razor Power Management</source>
        <translation>Razor Energieverwaltung</translation>
    </message>
</context>
</TS>