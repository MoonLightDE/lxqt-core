<?xml version="1.0" ?><!DOCTYPE TS><TS language="eu" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Bilatu komando bat</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>Razor Shortcut Editor</source>
        <translation>Razor lasterbide-editorea</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Deskribapena</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Lasterbidea</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Komandoa</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Gehitu berria</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Kendu</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Gehitu taldea</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Berrezarri</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Itxi</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Bat ere ez</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Gehitu lasterbidea</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Kendu</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Talde berria</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Berrezarri aldaketak</translation>
    </message>
</context>
</TS>