<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Znajdź polecenie</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>Razor Shortcut Editor</source>
        <translation>Edytor Skrótów Razor</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Skrót</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Polecenie</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Dodaj grupę</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Reset</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Brak</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Dodaj skrót</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Dodaj grupę</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Resetuj zmiany</translation>
    </message>
</context>
</TS>