<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>尋找指令</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>Razor Shortcut Editor</source>
        <translation>Razor快捷鍵編輯器</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>快捷鍵</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>指令</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>新增</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>新增群組</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>重設</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>關閉</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>無</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>增加快捷鍵</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>移除</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>新群組</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>重設更改</translation>
    </message>
</context>
</TS>