<?xml version="1.0" ?><!DOCTYPE TS><TS language="th_TH" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>หาคำสั่ง</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>Razor Shortcut Editor</source>
        <translation>ตัวแก้ไขปุ่มลัด Razor</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>รายละเอียด</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>ปุ่มลัด</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>คำสั่ง</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>เพิ่มใหม่</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>ลบทิ้ง</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>เพิ่มกลุ่ม</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>กลับค่าเดิม</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>ปิด</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>ไม่ต้อง</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>เพิ่มปุ่มลัด</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>ลบทิ้ง</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>กลุ่มใหม่</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>กลับค่าเดิม</translation>
    </message>
</context>
</TS>