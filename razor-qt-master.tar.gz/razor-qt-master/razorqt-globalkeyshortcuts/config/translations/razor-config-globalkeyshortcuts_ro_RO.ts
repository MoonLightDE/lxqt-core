<?xml version="1.0" ?><!DOCTYPE TS><TS language="ro_RO" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Caută o comandă</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>Razor Shortcut Editor</source>
        <translation>Editor acceleratori Razor</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descriere</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Accelerator</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Comandă</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Adaugă nou</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Elimină</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Adaugă grup</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Resetează</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Închide</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Nimic</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Adaugă accelerator</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Elimină</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Grup nou</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Resetează modificările</translation>
    </message>
</context>
</TS>