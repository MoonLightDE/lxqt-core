<?xml version="1.0" ?><!DOCTYPE TS><TS language="de_DE" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Finde einen Befehl</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>Razor Shortcut Editor</source>
        <translation>Razor Hotkey Editor</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Hotkey</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Befehl</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Hinzufügen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Gruppe hinzufügen</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Verwerfen</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Kein</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Hotkey hinzufügen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Neue Gruppe</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Änderungen verwerfen</translation>
    </message>
</context>
</TS>