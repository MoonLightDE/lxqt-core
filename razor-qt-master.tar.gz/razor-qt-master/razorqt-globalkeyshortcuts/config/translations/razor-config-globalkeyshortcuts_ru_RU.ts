<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru_RU" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Find a command</source>
        <translation>Найти команду</translation>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>Razor Shortcut Editor</source>
        <translation>Редактор сочетаний клавиш Razor </translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Сочетание клавиш</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Команда</translation>
    </message>
    <message>
        <source>Add New</source>
        <translation>Добавить новое</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Add Group</source>
        <translation>Добавить группу</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>Не задано</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation>Добавить сочетание клавиш</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>New Group</source>
        <translation>Новая группа</translation>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation>Отменить изменения</translation>
    </message>
</context>
</TS>