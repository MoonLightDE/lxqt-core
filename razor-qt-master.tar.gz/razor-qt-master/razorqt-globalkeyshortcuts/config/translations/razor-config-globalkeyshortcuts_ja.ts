<?xml version="1.0" ?><!DOCTYPE TS><TS language="ja" version="2.0">
<context>
    <name>CommandFinder</name>
    <message>
        <source>...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Find a command</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ShortcutConfigWindow</name>
    <message>
        <source>Razor Shortcut Editor</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Command</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Add New</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Add Group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
</context>
<context>
    <name>ShortcutEditor</name>
    <message>
        <source>None</source>
        <translation>なし</translation>
    </message>
    <message>
        <source>Add Shortcut</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>New Group</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Reset Changes</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>