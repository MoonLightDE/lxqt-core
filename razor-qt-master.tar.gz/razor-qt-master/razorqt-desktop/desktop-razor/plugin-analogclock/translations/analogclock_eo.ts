<?xml version="1.0" ?><!DOCTYPE TS><TS language="eo" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Agordoj pri analoga horloĝo</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Montri &amp;sekundojn</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Horloĝo</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Horloĝo:</translation>
    </message>
</context>
</TS>