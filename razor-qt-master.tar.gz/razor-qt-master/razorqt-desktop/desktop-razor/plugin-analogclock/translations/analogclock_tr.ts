<?xml version="1.0" ?><!DOCTYPE TS><TS language="tr" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Basit saat ayarları</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>&amp;Saniye kolunu göster</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Saat</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>