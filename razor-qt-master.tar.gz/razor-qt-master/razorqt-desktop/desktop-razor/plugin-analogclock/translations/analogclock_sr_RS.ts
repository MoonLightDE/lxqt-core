<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr_RS" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Подешавање аналогног сата</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Прикажи &amp;секундару</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Сат</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>