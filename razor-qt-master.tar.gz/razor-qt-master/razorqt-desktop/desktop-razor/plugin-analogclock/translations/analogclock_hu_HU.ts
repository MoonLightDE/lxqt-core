<?xml version="1.0" ?><!DOCTYPE TS><TS language="hu_HU" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Az analóg óra beállításai</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Má&amp;sodpercmutató megjelenítése</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Óra</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>