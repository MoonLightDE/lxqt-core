<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Configurações do relógio analógico</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Exibir o ponteiro dos &amp;segundos</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Relógio</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Relógio:</translation>
    </message>
</context>
</TS>