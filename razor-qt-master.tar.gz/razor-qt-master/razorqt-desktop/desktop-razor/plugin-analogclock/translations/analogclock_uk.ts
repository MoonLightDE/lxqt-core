<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Налаштування аналогового годинника</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Показувати &amp;секундну стрілку</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Годинник</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Годинник:</translation>
    </message>
</context>
</TS>