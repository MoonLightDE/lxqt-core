<?xml version="1.0" ?><!DOCTYPE TS><TS language="sl" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Nastavitve analogne ure</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Pokaži &amp;sekundni kazalec</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Ura</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>