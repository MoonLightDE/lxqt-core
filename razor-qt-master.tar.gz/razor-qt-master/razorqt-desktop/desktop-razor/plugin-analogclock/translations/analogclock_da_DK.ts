<?xml version="1.0" ?><!DOCTYPE TS><TS language="da_DK" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Analog urindstillinger</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Vis &amp;sekundviser</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Ur</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Ur:</translation>
    </message>
</context>
</TS>