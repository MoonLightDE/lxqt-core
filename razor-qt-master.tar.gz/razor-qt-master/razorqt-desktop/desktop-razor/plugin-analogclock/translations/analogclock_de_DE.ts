<?xml version="1.0" ?><!DOCTYPE TS><TS language="de_DE" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Analoge Uhr Einstellungen</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Zeige &amp;Sekungenzeiger </translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Uhr</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Uhr:</translation>
    </message>
</context>
</TS>