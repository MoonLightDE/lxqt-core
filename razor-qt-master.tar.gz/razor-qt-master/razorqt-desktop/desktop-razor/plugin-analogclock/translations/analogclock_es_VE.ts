<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_VE" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Configuraciones de reloj analogico</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Mostrar &amp;segundos</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Reloj</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Dia y hora</translation>
    </message>
</context>
</TS>