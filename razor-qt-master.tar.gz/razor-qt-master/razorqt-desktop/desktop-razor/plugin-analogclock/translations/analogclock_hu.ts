<?xml version="1.0" ?><!DOCTYPE TS><TS language="hu" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <location filename="../configuredialog.ui" line="14"/>
        <source>Analog clock settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../configuredialog.ui" line="23"/>
        <source>Show &amp;seconds hand</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clock.cpp" line="91"/>
        <source>Clock</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>