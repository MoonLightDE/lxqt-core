<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>模拟时钟设置</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>显示&amp;秒针</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>时钟</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>时钟：</translation>
    </message>
</context>
</TS>