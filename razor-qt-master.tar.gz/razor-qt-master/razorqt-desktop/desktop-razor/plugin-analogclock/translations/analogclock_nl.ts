<?xml version="1.0" ?><!DOCTYPE TS><TS language="nl" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Analoge klok instellingen</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Toon &amp;seconden wijzer</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>klok</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>