<?xml version="1.0" ?><!DOCTYPE TS><TS language="el_GR" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Ρυθμίσεις αναλογικού ρολογιού</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Εμφάνιση δείκτη &amp;δευτερολέπτων</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Ρολόι</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Ρολόι:</translation>
    </message>
</context>
</TS>