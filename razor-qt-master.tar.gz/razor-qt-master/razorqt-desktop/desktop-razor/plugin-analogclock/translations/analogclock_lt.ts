<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Analoginio laikrodžio nuostatos</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Rodyti sekundžių rodyklę</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Laikrodis</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>