<?xml version="1.0" ?><!DOCTYPE TS><TS language="ar" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>إعدادات ساعة العقارب</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>إظهار عقرب ال&amp;ثَّواني</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>السَّاعة</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>السَّاعة:</translation>
    </message>
</context>
</TS>