<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Ustawienia zegara analogowego</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Wyświetl &amp;sekundnika</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Zegar</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Zegar:</translation>
    </message>
</context>
</TS>