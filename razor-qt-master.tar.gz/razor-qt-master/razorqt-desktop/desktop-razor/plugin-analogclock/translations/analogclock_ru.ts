<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Аналоговые настройки часов</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation> Показать стрелка &amp;секунд </translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>часы</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Часы:</translation>
    </message>
</context>
</TS>