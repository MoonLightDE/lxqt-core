<?xml version="1.0" ?><!DOCTYPE TS><TS language="th_TH" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>ค่าตั้งนาฬิกาแอนะล็อก</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>แสดง&amp;เข็มวินาที</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>นาฬิกา</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>นาฬิกา:</translation>
    </message>
</context>
</TS>