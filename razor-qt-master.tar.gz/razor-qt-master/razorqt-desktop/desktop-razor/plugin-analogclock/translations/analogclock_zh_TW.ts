<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>類比時鐘設定</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>顯示秒針(&amp;s)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>時鐘</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>時鐘:</translation>
    </message>
</context>
</TS>