<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru_RU" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Настройки &quot;Часов с циферблатом&quot;</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Показывать &amp;секундную стрелку</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Часы</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Часы</translation>
    </message>
</context>
</TS>