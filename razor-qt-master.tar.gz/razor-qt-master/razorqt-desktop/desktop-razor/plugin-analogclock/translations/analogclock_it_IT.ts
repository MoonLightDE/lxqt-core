<?xml version="1.0" ?><!DOCTYPE TS><TS language="it_IT" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Impostazioni orologio analogico</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Mostra &amp;secondi</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Orologio</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Orologio:</translation>
    </message>
</context>
</TS>