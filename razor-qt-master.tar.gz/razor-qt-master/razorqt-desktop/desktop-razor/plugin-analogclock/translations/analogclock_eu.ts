<?xml version="1.0" ?><!DOCTYPE TS><TS language="eu" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Erloju analogikoaren ezarpenak</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Erakutsi &amp;segundoen orratza</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Erlojua</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Erlojua:</translation>
    </message>
</context>
</TS>