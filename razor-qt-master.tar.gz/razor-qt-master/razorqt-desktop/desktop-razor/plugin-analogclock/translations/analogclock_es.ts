<?xml version="1.0" ?><!DOCTYPE TS><TS language="es" version="2.0">
<context>
    <name>ConfigureDialog</name>
    <message>
        <source>Analog clock settings</source>
        <translation>Configuración del reloj analógico</translation>
    </message>
    <message>
        <source>Show &amp;seconds hand</source>
        <translation>Mostrar manecilla de &amp;segundos</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Clock</source>
        <translation>Reloj</translation>
    </message>
    <message>
        <source>Clock:</source>
        <translation>Reloj:</translation>
    </message>
</context>
</TS>