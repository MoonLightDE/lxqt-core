<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_VE" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>Hola mundo:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>Despliega un texto en el fondo de la pantalla</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>Editar el html</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation>Despliega un texto en el fondo de la pantalla, el componente es depurado </translation>
    </message>
</context>
</TS>