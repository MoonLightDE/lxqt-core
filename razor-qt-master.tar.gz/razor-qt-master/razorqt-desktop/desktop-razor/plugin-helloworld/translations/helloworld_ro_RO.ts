<?xml version="1.0" ?><!DOCTYPE TS><TS language="ro_RO" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>Salutare lume:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>Afișează configurația text:</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>Editează HTML</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation>Afișează text simplu. O aplicație de depanare/exemplu.</translation>
    </message>
</context>
</TS>