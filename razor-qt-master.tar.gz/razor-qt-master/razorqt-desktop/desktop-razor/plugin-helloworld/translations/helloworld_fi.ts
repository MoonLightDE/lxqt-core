<?xml version="1.0" ?><!DOCTYPE TS><TS language="fi" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>Hei maailma:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>Muokkaa HTML:ää</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>