<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>Привіт, світ:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>Показує налаштування тексту</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>Редагувати HTML</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation>Показує простий текст. Віджет для відлагодження/зразковий.</translation>
    </message>
</context>
</TS>