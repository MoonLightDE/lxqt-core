<?xml version="1.0" ?><!DOCTYPE TS><TS language="eu" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>Kaixo mundua:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>Bistaratu testu-konfigurazioa</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>Editatu HTMLa</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation>Bistaratu testu sinplea. Arazketa/eredutarako trepeta.</translation>
    </message>
</context>
</TS>