<?xml version="1.0" ?><!DOCTYPE TS><TS language="de_DE" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>Hallo Welt:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>Anzeigetext Konfiguration</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>Bearbeite HTML</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation>Einfachen Text anzeigen.  Debug/Beispiel Widget.</translation>
    </message>
</context>
</TS>