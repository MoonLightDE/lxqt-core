<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>Witaj świecie:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>Konfiguracja wyświetlonego tekstu</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>Edytuj HTML</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>