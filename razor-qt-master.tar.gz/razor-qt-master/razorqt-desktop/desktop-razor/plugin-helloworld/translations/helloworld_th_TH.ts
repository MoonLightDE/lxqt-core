<?xml version="1.0" ?><!DOCTYPE TS><TS language="th_TH" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>สวัสดีชาวโลก:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>แสดงการตั้งค่าข้อความ</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>แก้ไข HTML</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation>แสดงข้อความแบบเรียบง่าย การดีบั๊ก/วิดเจ็ตตัวอย่าง</translation>
    </message>
</context>
</TS>