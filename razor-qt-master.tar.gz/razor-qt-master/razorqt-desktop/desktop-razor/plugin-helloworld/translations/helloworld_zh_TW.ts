<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>世界你好:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>顯示文字設定</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>編輯HTML</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation>顯示簡單的文字。這是一個範例/除錯小工具</translation>
    </message>
</context>
</TS>