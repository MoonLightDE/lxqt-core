<?xml version="1.0" ?><!DOCTYPE TS><TS language="da_DK" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>Hej verden:</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>Vis konfiguration af tekst</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>Redigér HTML</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation>Vis simpel tekst. En fejlsøgnings/prøve widget.</translation>
    </message>
</context>
</TS>