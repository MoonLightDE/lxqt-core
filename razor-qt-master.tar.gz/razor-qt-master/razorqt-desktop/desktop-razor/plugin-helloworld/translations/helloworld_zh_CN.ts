<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.0">
<context>
    <name>HelloWorld</name>
    <message>
        <source>Hello World:</source>
        <translation>Hello World：</translation>
    </message>
    <message>
        <source>Display Text Configuretion</source>
        <translation>显示文本配置</translation>
    </message>
    <message>
        <source>Edit HTML</source>
        <translation>编辑 HTML</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display simple text. A debugging/sample widget.</source>
        <translation>显示简单的文本。一个调试/样版组件。</translation>
    </message>
</context>
</TS>