<?xml version="1.0" ?><!DOCTYPE TS><TS language="th_TH" version="2.0">
<context>
    <name>QObject</name>
    <message>
        <source>Display a notepad</source>
        <translation>แสดงแผ่นบันทึก</translation>
    </message>
    <message>
        <source>Notepad:</source>
        <translation>แผ่นบันทึก</translation>
    </message>
</context>
</TS>