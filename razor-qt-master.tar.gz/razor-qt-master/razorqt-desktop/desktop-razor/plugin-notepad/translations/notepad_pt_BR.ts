<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.0">
<context>
    <name>QObject</name>
    <message>
        <source>Display a notepad</source>
        <translation>Exibir um bloco de nota</translation>
    </message>
    <message>
        <source>Notepad:</source>
        <translation>Bloco de nota:</translation>
    </message>
</context>
</TS>