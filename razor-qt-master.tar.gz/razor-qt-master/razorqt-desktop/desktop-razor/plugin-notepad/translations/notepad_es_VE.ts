<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_VE" version="2.0">
<context>
    <name>QObject</name>
    <message>
        <source>Display a notepad</source>
        <translation>Despliega un block de notas incrustado</translation>
    </message>
    <message>
        <source>Notepad:</source>
        <translation>Block de notas</translation>
    </message>
</context>
</TS>