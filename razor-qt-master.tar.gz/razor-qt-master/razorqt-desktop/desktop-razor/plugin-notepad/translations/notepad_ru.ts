<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru" version="2.0">
<context>
    <name>QObject</name>
    <message>
        <source>Display a notepad</source>
        <translation>Показать блокнот</translation>
    </message>
    <message>
        <source>Notepad:</source>
        <translation>Блокнот:</translation>
    </message>
</context>
</TS>