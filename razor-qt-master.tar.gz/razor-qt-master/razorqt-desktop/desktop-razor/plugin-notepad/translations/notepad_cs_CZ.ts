<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs_CZ" version="2.0">
<context>
    <name>QObject</name>
    <message>
        <source>Display a notepad</source>
        <translation>Zobrazit zápisník</translation>
    </message>
    <message>
        <source>Notepad:</source>
        <translation>Zápisník:</translation>
    </message>
</context>
</TS>