<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.0">
<context>
    <name>QObject</name>
    <message>
        <source>Display a notepad</source>
        <translation>显示笔记本</translation>
    </message>
    <message>
        <source>Notepad:</source>
        <translation>笔记本：</translation>
    </message>
</context>
</TS>