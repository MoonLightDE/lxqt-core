<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.0">
<context>
    <name>QObject</name>
    <message>
        <source>Display a notepad</source>
        <translation>Wyświetl notatnik</translation>
    </message>
    <message>
        <source>Notepad:</source>
        <translation>Notatnik:</translation>
    </message>
</context>
</TS>