<?xml version="1.0" ?><!DOCTYPE TS><TS language="it_IT" version="2.0">
<context>
    <name>QObject</name>
    <message>
        <source>Display a notepad</source>
        <translation>Visualizza un blocco note</translation>
    </message>
    <message>
        <source>Notepad:</source>
        <translation>Blocco note:</translation>
    </message>
</context>
</TS>