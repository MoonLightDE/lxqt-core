<?xml version="1.0" ?><!DOCTYPE TS><TS language="de_DE" version="2.0">
<context>
    <name>QObject</name>
    <message>
        <source>Display a notepad</source>
        <translation>Ein Notepad anzeigen</translation>
    </message>
    <message>
        <source>Notepad:</source>
        <translation>Notepad:</translation>
    </message>
</context>
</TS>