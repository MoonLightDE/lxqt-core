<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Збій копіювання файлу</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Не вдалося зкопіювати файл з %1 до %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Налаштування перегляду значків</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Показує вміст обраної теки</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Перегляд значків:</translation>
    </message>
</context>
</TS>