<?xml version="1.0" ?><!DOCTYPE TS><TS language="el_GR" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Σφάλμα αντιγραφής αρχείου</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Αδύνατη η αντιγραφή του αρχείου %1 στο %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Διαμόρφωση προβολής εικονιδίων</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Εμφάνιση περιεχομένων του δεδομένου φακέλου/καταλόγου</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Προβολή εικονιδίων:</translation>
    </message>
</context>
</TS>