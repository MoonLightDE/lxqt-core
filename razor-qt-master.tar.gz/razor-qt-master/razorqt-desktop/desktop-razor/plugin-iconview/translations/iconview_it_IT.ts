<?xml version="1.0" ?><!DOCTYPE TS><TS language="it_IT" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Errore di copia del file</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Impossibile copiare il file %1 in %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Configurazione di Vista icone</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Visualizza il contenuto di una cartella selezionata</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Vista icone:</translation>
    </message>
</context>
</TS>