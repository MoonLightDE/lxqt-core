<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Chyba při kopírování souboru</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Nelze zkopírovat soubor %1 do %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Nastavení pohledu s ikonami</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Zobrazit obsah daného adresáře/složky</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Pohled s ikonami</translation>
    </message>
</context>
</TS>