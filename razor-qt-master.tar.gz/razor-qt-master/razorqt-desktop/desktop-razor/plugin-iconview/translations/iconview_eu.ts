<?xml version="1.0" ?><!DOCTYPE TS><TS language="eu" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Errorea fitxategia kopiatzean</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Ezin da %1 fitxategia %2-(e)ra kopiatu</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Ikono ikuspegiaren konfigurazioa</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Bistaratu emandako direktorio/karpetaren edukiak</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Ikono ikuspegia:</translation>
    </message>
</context>
</TS>