<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Wystąpił błąd podczas kopiowania</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Nie można skopiować pliku %1 do %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Konfiguracja widoku ikon</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Pokaż treść podanych katalogów/folderów</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Widok ikon:</translation>
    </message>
</context>
</TS>