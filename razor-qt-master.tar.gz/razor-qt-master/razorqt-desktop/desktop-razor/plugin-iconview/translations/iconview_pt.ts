<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Erro ao copiar ficheiro</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Não foi possível copiar %1 para %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Configuração da vista de icones</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Mostrar conteúdo do diretório/pasta</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Vista de ícones:</translation>
    </message>
</context>
</TS>