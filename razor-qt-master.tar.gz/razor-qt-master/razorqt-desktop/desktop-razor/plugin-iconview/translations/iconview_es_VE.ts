<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_VE" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Error al copiar el archivo</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>No se copio el archivo %1 a %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Configuracion de icono</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Desplegar contenido del directorio</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Vista de iconos:</translation>
    </message>
</context>
</TS>