<?xml version="1.0" ?><!DOCTYPE TS><TS language="fi" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Tiedoston kopiointivirhe</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Tiedostoa %1 ei voi kopioida kohteeseen %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Kuvakenäkymän asetukset</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Näytä määrätyn kansion sisältö</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Kuvakenäkymä:</translation>
    </message>
</context>
</TS>