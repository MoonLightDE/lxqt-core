<?xml version="1.0" ?><!DOCTYPE TS><TS language="ro_RO" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Eroare de copiere fișier</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Nu s-a putut copia fișierul din %1 în %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Configurare vedere pictograme</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Afișează conținutul directorului/dosarului dat</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Vedere pictograme:</translation>
    </message>
</context>
</TS>