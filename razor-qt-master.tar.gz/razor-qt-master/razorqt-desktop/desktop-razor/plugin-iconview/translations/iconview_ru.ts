<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Ошибка при копировании файла</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Невозможно скопировать файл %1 в %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Настройки просмотра иконок</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Показать содержимое выбранного каталога/папки</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Просмотр иконок:</translation>
    </message>
</context>
</TS>