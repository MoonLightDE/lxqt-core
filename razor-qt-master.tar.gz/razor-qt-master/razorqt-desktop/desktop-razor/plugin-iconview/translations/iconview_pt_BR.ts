<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Erro Ao Copiar Aquivo</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>Não foi possível copiar %1 para %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Configuração Da Visualização Do Ícone</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Exibir o conteúdo de um dado diretório/pasta</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Visualização Do Ícone:</translation>
    </message>
</context>
</TS>