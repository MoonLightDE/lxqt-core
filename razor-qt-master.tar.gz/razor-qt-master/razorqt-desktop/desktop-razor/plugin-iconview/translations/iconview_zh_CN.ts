<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>复制文件出错</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>无法复制文件 %1 到 %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>图标视图配置</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>显示给定目录/文件夹的内容</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>图标视图：</translation>
    </message>
</context>
</TS>