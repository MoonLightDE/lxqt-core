<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>複製檔案錯誤</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>無法將檔案%1複製到%2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>資料夾檢視設定</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>顯示指定的目錄/資料夾的內容</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>資料夾檢視:</translation>
    </message>
</context>
</TS>