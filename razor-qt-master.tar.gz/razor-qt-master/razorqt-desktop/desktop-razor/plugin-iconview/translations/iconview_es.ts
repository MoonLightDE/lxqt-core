<?xml version="1.0" ?><!DOCTYPE TS><TS language="es" version="2.0">
<context>
    <name>IconScene</name>
    <message>
        <source>Copy File Error</source>
        <translation>Copiar Archivo de Error</translation>
    </message>
    <message>
        <source>Cannot copy file %1 to %2</source>
        <translation>No es posible copiar archivo %1 a %2</translation>
    </message>
</context>
<context>
    <name>IconView</name>
    <message>
        <source>Icon View Configuration</source>
        <translation>Configuración de Vista de Iconos</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Display content of the given directory/folder</source>
        <translation>Mostrar contenido del directorio indicado</translation>
    </message>
    <message>
        <source>Icon View:</source>
        <translation>Vista de Iconos:</translation>
    </message>
</context>
</TS>