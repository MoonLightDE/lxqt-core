<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru" version="2.0">
<context>
    <name>DesktopBackgroundDialog</name>
    <message>
        <source>Desktop Background Settings</source>
        <translation>Настройки фона</translation>
    </message>
    <message>
        <source>Background &amp;Color...</source>
        <translation>Обои и фон...</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Get Wallpaper Image...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Get System Wallpaper...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Keep Image Aspect Ratio</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select Background Color</source>
        <translation>Выбор цвета фона</translation>
    </message>
    <message>
        <source>Select Wallpaper Image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Images (*.png *.xpm *.jpg *.jpeg *.svg)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Select System Wallpaper Image</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DesktopScene</name>
    <message>
        <source>Unlock Desktop...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Add New Desktop Widget...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Remove Plugin...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Configure Plugin...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Set Desktop Background...</source>
        <translation>Поменять фон...</translation>
    </message>
    <message>
        <source>About Razor...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>New Desktop Widget</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>There is no free space to add new desktop widget</source>
        <translation>Нет места что бы добавить еще один виджет</translation>
    </message>
    <message>
        <source>Remove Desktop Widget?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Really remove this widget &apos;%1&apos;?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Lock Desktop...</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>No info available</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>RazorWorkSpace</name>
    <message>
        <source>Background Change</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>Do you want to change desktop background?</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>RazorWorkSpaceManager</name>
    <message>
        <source>Fully featured desktop implementation with all Razor&apos;s bells and whistles</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>
